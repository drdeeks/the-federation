# AGENTS.md — character-kit-watchtower-bridge

> Cold-start handoff. Read this FIRST in any new session touching this repo.

**Maintenance rule:** this file, `README.md`, and `CHANGELOG.md` are kept in
sync on every change. Status (§8) is updated with a dated line; history goes in
`CHANGELOG.md`. Do not let any of the three drift.

---

## 1. WHAT THIS IS

A **translator bridge** between two independent, pre-existing primitives:

- **Character Kit** (`@drdeeks/character-kit`) — local behavioral enforcement
  (habit loop, acknowledgment capture, fail-closed gating). Owns NO
  identity/soul/persona. Truth: its repo `AGENTS.md`.
- **Federation Watchtower** (`@federation-watchtower/sdk` + `federation-serverless`)
  — federation / control / observability (registry, heartbeats, events, leases,
  guardrails, audit trail, public projection).

The bridge converts Character Kit enforcement activity → normalized Watchtower
events, and Watchtower results → adapter-visible state. **It owns no policy** and
is the only layer that knows both sides.

Separate package from `google-agentic-projects` (the hackathon repo). The
submission uses the bridge; the bridge is not the submission.

## 2. THE NON-NEGOTIABLE RULE — FAIL-CLOSED

Delivery failure never grants permission.

- Watchtower unavailable → CK stays fail-closed; queue/retry; **no release**.
- Character Kit unavailable → cannot authorize; **block**.
- Adapter crashes → CK continues; no release inferred.
- Socket / network lost → treated as CK unavailable; **block**.
- Duplicate event → suppressed (`event_id`, then `correlation_id + sequence`).
- Out-of-order event → preserved for audit; state NOT advanced.

Enforced in `src/failure.ts`; tested in `tests/adapter-roundtrip.test.ts` +
`tests/event-normalizer.test.ts`.

## 3. REQUIRED SEPARATION (verified, not assumed)

- Character Kit MUST NOT depend on Watchtower.
- Watchtower MUST NOT depend on Character Kit.
- The adapter is the only cross-system layer and is **disposable**: removing it
  leaves both primitives fully working. That is the correctness test.

## 4. REPO LAYOUT (canonical)

```
src/
  contracts.ts        normalized event types — types only, no logic
  config.ts           config validation/parse only
  failure.ts          fail-closed classification (the non-negotiable)
  events.ts           event name constants + makeEvent
  state.ts            dedupe / ordering / retry state
  adapter.ts          orchestration (no policy, no storage engine)
  index.ts            PUBLIC API surface only
  bridge/
    character-kit.ts  Character Kit ONLY (no Watchtower imports/creds)
    watchtower.ts     Watchtower ONLY (uses @federation-watchtower/sdk)
  normalization/
    event-normalizer.ts  CK result -> normalized event
    dedupe.ts             idempotency / duplicate suppression
    ordering.ts           sequence correlation / out-of-order audit
  transport/
    transport.ts     Transport interface (no vendor logic)
    http.ts          HTTP -> Watchtower via SDK (no CK logic)
  runtime/
    lifecycle.ts     start/stop orchestration
    shutdown.ts      graceful teardown
tests/                unit (config, contracts, event-normalizer, adapter-roundtrip)
docs/symbol-matrix.md Phase 0 source inventory (verified exports)
CHANGELOG.md          dated, append-only trail
```

Each file's "must not contain" list is in the build blueprint. Honor it.

## 5. VERIFIED UPSTREAM MAP (Phase 0 — see docs/symbol-matrix.md)

| Bridge helper | Verified upstream |
|---------------|------------------|
| `gateAction` | Character Kit `Enforcer.execute_tool` / `EnforcerClient` |
| `checkHabit` | Character Kit habit injection |
| `submitAcknowledgement` | Character Kit ack capture |
| `sendHeartbeat` | `WatchtowerClient.heartbeat` + `Enforcer.heartbeat` |
| `emitEvent` | `WatchtowerClient.emitEvent(OperationalEvent)` |
| `registerAgent` | `FederationOwnerClient.registerAgent(manifest)` |
| `validateLease` | `WatchtowerClient.validateLease` |

## 6. STACK / TOOLING

- TypeScript (ESM, `target: ES2022`, `moduleResolution: Bundler`).
- Runtime: Node >= 20.
- Test: `node --test` via `tsx`. Typecheck: `tsc --noEmit`.
- No framework; no bundler needed for dev (tsx runs TS directly).

## 7. OPERATING RULES

1. **Read this file first.**
2. **Verify before claiming.** Every "done" needs real output: `npm run validate`
   (tsc) and `npm test` must pass. No fabricated output, ever.
3. **One canonical file per concept.** Zero duplicates; the canonical file wins.
4. **Trash > purge.** Never `rm -rf` source. Move to `.scratch/` if it must go.
5. **No hardcoded paths/secrets.** Self-resolving paths; secrets from `.env`
   (gitignored). `.env.example` is the only committed config template.
6. **Keep the boundary.** If a change makes Character Kit import Watchtower
   (or vice versa), it is wrong. Revert.
7. **Fail-closed defaults.** Never add a permissive fallback "for convenience."
8. **Update the triad.** On every change: this file (§8 status), `README.md`
   (status section), and `CHANGELOG.md` (append a dated entry). Keep them synced.
9. **Git commit before big changes**; keep the tree clean between steps.

## 8. CURRENT STATUS (update with a dated line on every change)

- 2026-08-10 — Phase 0 (source inventory) DONE — `docs/symbol-matrix.md`.
- 2026-08-10 — Phase 1 (contracts) DONE — `contracts.ts`, `events.ts`, `failure.ts`.
- 2026-08-10 — Phase 2 (Character Kit client) BOUNDARY STUB only — `character-kit.ts`
  throws "unavailable" by design; real socket/Python transport not wired.
- 2026-08-10 — Phase 3 (Watchtower client) DONE at surface — `watchtower.ts` uses
  the real SDK; NOT exercised against live `fapi.drdeeks.xyz` in tests.
- 2026-08-10 — Phase 4 (adapter) DONE structurally; relies on Phase 2 stub for CK.
- 2026-08-10 — Phase 5 (failure hardening) fail-closed LOGIC done + unit-tested;
  live crash/network simulation NOT yet integration-tested.
- 2026-08-10 — Phase 6 (topology: root/user/local) NOT started.
- 2026-08-10 — **Tests: 12/12 unit pass; `tsc --noEmit` clean.** Coverage is
  contracts + normalization + fail-closed only (no live network, no real CK socket).

## 9. KNOWN GAPS (do not claim these work)

- Character Kit client is a **stub**; real enforcement flow unverified end-to-end.
- No integration test against `fapi.drdeeks.xyz` or a local Watchtower.
- `unix-socket.ts` / `mcp.ts` transports: NOT created (deferred full-tree items).
- `scripts/` (start-dev / validate / replay-events): NOT created.
- e2e topology tests (root / user / agent-local): NOT created.
- x402 payment, org-room, sitcom UI: OUT OF SCOPE — live in Watchtower/Federation
  product, not here.

## 10. NEXT STEPS

- [ ] Wire the real Character Kit client (Phase 2): socket or Python `EnforcerClient`.
- [ ] Integration test: emit a real event to a local/dev Watchtower.
- [ ] Add `unix-socket.ts` transport + `scripts/`.
- [ ] e2e topology tests (root-owned / user-owned / agent-local).
- [ ] Use the bridge inside hackathon submission(s) as the disclosure backbone.

## 11. AUTHORITY / READING ORDER

1. `AGENTS.md` (this file) — orientation + rules.
2. `CHANGELOG.md` — dated history.
3. `docs/symbol-matrix.md` — verified upstream exports (Phase 0).
4. `README.md` — purpose + limitations for outsiders.
5. `src/failure.ts` — the non-negotiable; read before touching adapters.
