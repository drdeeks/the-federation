# Character Kit ⇄ Watchtower Bridge

> A translator between two independent primitives. It owns no policy.

A thin, **disposable** layer that lets your two existing systems talk:

| Primitive | Role | Source of truth |
|-----------|------|-----------------|
| **Character Kit** (`@drdeeks/character-kit`) | Local behavioral enforcement — habit loop, acknowledgment capture, fail-closed gating. No identity/soul/persona. | `agent-character-kit` repo `AGENTS.md` |
| **Federation Watchtower** (`@federation-watchtower/sdk` + `federation-serverless`) | Federation / control / observability — agent registry, heartbeats, events, leases, guardrails, audit trail. | `federation-watchtower` repo |

The bridge does exactly two things:

1. Character Kit enforcement activity → **normalized Watchtower events**.
2. Watchtower lease/guardrail/status results → **adapter-visible state**.

It is a translator, not a policy engine. It defines no habits, owns no identity,
owns no federation policy, and re-implements neither primitive.

---

## The non-negotiable: fail-closed

**Delivery failure never grants permission.**

| Condition | Behavior |
|-----------|----------|
| Watchtower unavailable | Character Kit stays fail-closed; queue/retry; **no release** |
| Character Kit unavailable | Cannot authorize; **block** |
| Adapter crashes | Character Kit continues; no release inferred |
| Socket / network lost | Treated as Character Kit unavailable; **block** |
| Event undeliverable | Bounded retry, idempotency key preserved |
| Duplicate event | Suppressed by `event_id`, then `correlation_id + sequence` |
| Out-of-order event | Preserved for audit; state NOT advanced |

Enforced in `src/failure.ts`; asserted by `tests/adapter-roundtrip.test.ts` and
`tests/event-normalizer.test.ts`.

---

## Boundaries (verified, not assumed)

- Character Kit MUST NOT depend on Watchtower.
- Watchtower MUST NOT depend on Character Kit.
- The adapter is the **only** cross-system layer and is **disposable**: remove
  it and both primitives still work. That is the correctness test.

---

## Status — what is proven vs. not

**Proven (12/12 unit tests pass, `tsc --noEmit` clean):**

- Config resolution (fail-closed on missing secret).
- Normalized event construction (unique `event_id`, sane defaults).
- Enforcement-result → event mapping (allowed / blocked).
- Dedupe (by `event_id`, then `correlation_id + sequence`).
- Ordering (out-of-order detected; state not advanced).
- Fail-closed classification (CK down → block; WT down → retry).

**NOT proven (do not claim these work):**

- The live Character Kit enforcement socket / Python client — `character-kit.ts`
  is a **boundary stub** that throws "unavailable" by design.
- Live delivery to any Watchtower instance (`fapi.drdeeks.xyz` or local) — unit
  tests are hermetic; no test emits a real event over the network.
- Transports `unix-socket.ts` / `mcp.ts` — not created (deferred full-tree items).
- `scripts/` (start-dev / validate / replay-events) — not created.
- e2e topology tests (root / user / agent-local) — not created.
- x402 payment, org-rooms, sitcom UI — **out of scope**; they live in the
  Watchtower / Federation product, not here.

See `AGENTS.md` §8–§9 for the phase-by-phase breakdown and `CHANGELOG.md` for
the dated update trail.

---

## Relationship to the Google "All Things Agentic" hackathon

This bridge is **pre-existing platform infrastructure**, not a submission.
Per the Official Rules (hackathon repo `docs/rules.html`, line 856), pre-existing
code MUST be disclosed. This package is the **disclosure backbone**: a hackathon
submission is a *thin, newly built* ADK/Gemini agent layer that *uses* this bridge
+ Watchtower + Character Kit, with the platforms disclosed as prior work.

**Until the submission period opens, this bridge is scaffold + verified contracts
+ fail-closed logic only.** Real integration (live CK client, Watchtower delivery
tests, submission ADK layer) happens **in-period**. Anything claimed working
before then is limited to what the unit tests prove.

---

## Build & verify

```bash
npm install
npm run validate     # tsc --noEmit — typecheck gate
npm test            # node --test via tsx — 12 unit tests
```

## Layout

```
src/
  contracts.ts   normalized event types (types only)
  config.ts      config validation
  failure.ts     fail-closed classification  ← read this first
  events.ts      event constants + makeEvent
  state.ts       dedupe / ordering / retry
  adapter.ts     orchestration (no policy, no storage)
  index.ts       public API only
  bridge/        character-kit.ts (CK only) | watchtower.ts (WT only, real SDK)
  normalization/ event-normalizer | dedupe | ordering
  transport/     transport interface | http
  runtime/       lifecycle | shutdown
tests/           unit: config, contracts, event-normalizer, adapter-roundtrip
docs/symbol-matrix.md  Phase 0 verified upstream export map
CHANGELOG.md     dated, append-only update trail
AGENTS.md        cold-start handoff + operating rules
```

Maintained files: `AGENTS.md` (internals) · `README.md` (outsiders) ·
`CHANGELOG.md` (history). Keep all three in sync on every change.
